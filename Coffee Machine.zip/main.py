from programData import MENU,resources

# First I'll make the function for showing Report
# Take Input From the User


def report():
    return f"Water: {resources["water"]}ml\nMilk: {resources["milk"]}ml\nCoffee: {resources["coffee"]}g\nMoney: ${resources["Money"]}"

# for showing that the machine is under maintenance
def off_machine():
    exit()

# Now Add While Loop
while True:
    user_input = input("What would you like? (espresso/latte/cappuccino): ").lower()
    if user_input == "report":
        print(report())
    elif user_input == "off":
        off_machine()

# Now the coffee machine program
# First Write Espresso Logic
    if user_input == "espresso":
        if resources["water"] > MENU["espresso"]["ingredients"]["water"]:
            resources["water"] -= MENU["espresso"]["ingredients"]["water"]
            if resources["coffee"] > MENU["espresso"]["ingredients"]["coffee"]:
                resources["coffee"] -= MENU["espresso"]["ingredients"]["coffee"]
                print("Please Insert Coins.")
                ask_quarters=int(input("how many quarters?: "))*0.25
                ask_dimes=int(input("how many dimes?: "))*0.10
                ask_nickles=int(input("how many nickles?: "))*0.05
                ask_pennies=int(input("how many pennies?: "))*0.01
                user_paid = ask_quarters + ask_dimes + ask_nickles + ask_pennies
                if user_paid > MENU["espresso"]["cost"] or user_paid == MENU["espresso"]["cost"] :
                    resources["Money"] += MENU["espresso"]["cost"]
                    user_change = user_paid - MENU["espresso"]["cost"]
                    print(f"Here is ${round(user_change,2)} in change.")
                    print(f"Here's is your {user_input} ☕. Enjoy! ")
                else:
                    print("Sorry that's not enough money. Money refunded.")
            else:
                print("Sorry There is No Enough Coffee.")
        else:
            print("Sorry There is No Enough Water.")

    if user_input == "latte":
        if resources["water"] > MENU[f"{user_input}"]["ingredients"]["water"]:
            resources["water"] -= MENU[f"{user_input}"]["ingredients"]["water"]
            if resources["milk"] > MENU[f"{user_input}"]["ingredients"]["milk"]:
                resources["milk"] -= MENU[f"{user_input}"]["ingredients"]["milk"]
                if resources["coffee"] > MENU[f"{user_input}"]["ingredients"]["coffee"]:
                    resources["coffee"] -= MENU[f"{user_input}"]["ingredients"]["coffee"]
                    print("Please Insert Coins.")
                    ask_quarters = int(input("how many quarters?: ")) * 0.25
                    ask_dimes = int(input("how many dimes?: ")) * 0.10
                    ask_nickles = int(input("how many nickles?: ")) * 0.05
                    ask_pennies = int(input("how many pennies?: ")) * 0.01
                    user_paid = ask_quarters + ask_dimes + ask_nickles + ask_pennies
                    if user_paid > MENU[f"{user_input}"]["cost"] or user_paid == MENU[f"{user_input}"]["cost"]:
                        resources["Money"] += MENU[f"{user_input}"]["cost"]
                        user_change = user_paid - MENU[f"{user_input}"]["cost"]
                        print(f"Here is ${round(user_change, 2)} in change.")
                        print(f"Here's is your {user_input} ☕. Enjoy! ")
                    else:
                        print("Sorry that's not enough money. Money refunded.")
                else:
                    print("Sorry There is No Enough Coffee.")
            else:
                print("Sorry There is No Enough Milk.")
        else:
            print("Sorry There is No Enough Water.")

    if user_input == "cappuccino":
        if resources["water"] > MENU[f"{user_input}"]["ingredients"]["water"]:
            resources["water"] -= MENU[f"{user_input}"]["ingredients"]["water"]
            if resources["milk"] > MENU[f"{user_input}"]["ingredients"]["milk"]:
                resources["milk"] -= MENU[f"{user_input}"]["ingredients"]["milk"]
                if resources["coffee"] > MENU[f"{user_input}"]["ingredients"]["coffee"]:
                    resources["coffee"] -= MENU[f"{user_input}"]["ingredients"]["coffee"]
                    print("Please Insert Coins.")
                    ask_quarters = int(input("how many quarters?: ")) * 0.25
                    ask_dimes = int(input("how many dimes?: ")) * 0.10
                    ask_nickles = int(input("how many nickles?: ")) * 0.05
                    ask_pennies = int(input("how many pennies?: ")) * 0.01
                    user_paid = ask_quarters + ask_dimes + ask_nickles + ask_pennies
                    if user_paid > MENU[f"{user_input}"]["cost"] or user_paid == MENU[f"{user_input}"]["cost"]:
                        resources["Money"] += MENU[f"{user_input}"]["cost"]
                        user_change = user_paid - MENU[f"{user_input}"]["cost"]
                        print(f"Here is ${round(user_change, 2)} in change.")
                        print(f"Here's is your {user_input} ☕. Enjoy! ")
                    else:
                        print("Sorry that's not enough money. Money refunded.")
                else:
                    print("Sorry There is No Enough Coffee.")
            else:
                print("Sorry There is No Enough Milk.")
        else:
            print("Sorry There is No Enough Water.")