import pandas as pd
import turtle
from turtle import Turtle,Screen

# Screen Area
screen = Screen()
screen.title("U.S. States Game")
image = "blank_states_img.gif"
screen.addshape(image)
screen.setup(800,700)

turtle.shape(image)

# Pandas Area
states_data = pd.read_csv("50_states.csv")
states_list = states_data["state"].to_list()
x_y_coord = list(zip(states_data["x"],states_data["y"]))


guessed_states = []
score = 0
is_game_on = True
while is_game_on:
    guess = screen.textinput(f"Your Score {score}/50", "What's the Name of the State?").title()
    #Check the Guess in The states_list on not
    if guess in states_list:
        guessed_states.append(guess)
        print(guessed_states)
        score+=1
        guess_index = states_list.index(guess)
        x_y_state = x_y_coord[guess_index]
        new_turtle = Turtle()
        new_turtle.hideturtle()
        new_turtle.penup()
        new_turtle.goto(x_y_state)
        new_turtle.write(guess,align="center", font=("Arial", 10, "normal"))
    elif guess == "Exit":
        is_game_on = False
        missing_states = [state for state in states_list if state not in guessed_states]
        data_frame = pd.DataFrame(missing_states)
        data_frame.to_csv("Missing_States.csv")
        break
    elif len(guessed_states) == 50:
        is_game_on = False
        print(f"Congratulations You Completed The Game.\nYour Score is {score}.")







screen.exitonclick()